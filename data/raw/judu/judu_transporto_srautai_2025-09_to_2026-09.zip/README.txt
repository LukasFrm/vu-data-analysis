JUDU transporto srautai: 2025-09 through 2026-09

Source
- JUDU page: https://judu.lt/transporto-srautai/
- Historical ArcGIS table: https://arcgis.sisp.lt/arcgis/rest/services/VIS/Traffic_Volumes/MapServer/3
- Segment lookup layer: https://arcgis.sisp.lt/arcgis/rest/services/VIS/Traffic_Volumes/MapServer/0

Coverage
- Inclusive start: 2025-09-01 00:00:00
- Inclusive end: 2026-09-30 23:59:59
- Total raw records: 7,008,072
- Measurement points in lookup: 1,035
- Monthly segment-layer records used to build lookup: 10,588

Raw monthly CSV columns
- id: ArcGIS object ID
- measurementpoint: sensor/road-segment identifier
- count: published vehicle count for the interval
- datefrom, dateto: human-readable service timestamps (YYYY-MM-DD HH:MM:SS)
- hourfrom, hourto: published interval-hour fields
- divisor: published divisor field; retained without reinterpretation
- datefrom_ms, dateto_ms: original ArcGIS epoch-millisecond values

Important notes
- The CSV files preserve every returned record; no aggregation, imputation, or deduplication was applied.
- ArcGIS encodes the service's displayed local clock values as epoch milliseconds. The readable timestamps are decoded without applying a timezone shift so that they remain consistent with hourfrom/hourto.
- A measurement point may have fewer than all hourly intervals because sensors can start, stop, or have missing records.
- The dataset is too large for a single Excel worksheet. Use R, Python, DuckDB, SPSS, Stata, or import one monthly file at a time.
- Check JUDU/Susisiekimo paslaugos licensing and attribution terms before redistribution.

Record counts by month
- 2025-09: 686,504
- 2025-10: 698,091
- 2025-11: 687,373
- 2025-12: 659,428
- 2026-01: 560,477
- 2026-02: 406,292
- 2026-03: 377,210
- 2026-04: 355,942
- 2026-05: 369,113
- 2026-06: 337,736
- 2026-07: 598,648
- 2026-08: 656,333
- 2026-09: 614,925
